package TasteProfile;

public class TopThreeSongsImpl extends TopThreeSongs{
}
