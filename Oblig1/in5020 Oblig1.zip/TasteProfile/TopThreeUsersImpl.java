package TasteProfile;

public class TopThreeUsersImpl extends TopThreeUsers {}