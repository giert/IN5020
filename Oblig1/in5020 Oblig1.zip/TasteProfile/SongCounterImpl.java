package TasteProfile;

public class SongCounterImpl extends SongCounter{
}
