package TasteProfile;

public class SongProfileImpl extends SongProfile {

}
