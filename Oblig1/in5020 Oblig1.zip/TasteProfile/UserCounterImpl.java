package TasteProfile;

public class UserCounterImpl extends UserCounter{

}
