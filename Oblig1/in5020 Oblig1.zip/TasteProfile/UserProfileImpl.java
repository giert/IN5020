package TasteProfile;

public class UserProfileImpl extends UserProfile{

}
